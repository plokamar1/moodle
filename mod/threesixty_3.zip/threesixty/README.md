threesixty
==========

This Moodle module is designed to implement a 360 degree competency analysis. This method of assessment is also referred to as "multisource feedback." 

An individual compares his or her level of ability in a predefined list of competencies by rating themselves against a specific scenario. Each scenario highlights a specific skill that makes up the overall competency. This same set of questions is also answered by a set number of colleagues, clients, bosses, etc. in order to get a full (or 360 degree) view of the skill of the individual as perceived by others as well as him or herself.